export declare const version = "hdnode/5.7.0";
//# sourceMappingURL=_version.d.ts.map