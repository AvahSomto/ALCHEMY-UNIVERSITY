export const version = "hdnode/5.7.0";
