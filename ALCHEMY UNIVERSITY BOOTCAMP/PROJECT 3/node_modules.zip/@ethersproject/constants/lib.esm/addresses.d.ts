export declare const AddressZero = "0x0000000000000000000000000000000000000000";
//# sourceMappingURL=addresses.d.ts.map