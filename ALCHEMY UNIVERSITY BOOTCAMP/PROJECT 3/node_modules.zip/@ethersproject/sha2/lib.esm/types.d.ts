export declare enum SupportedAlgorithm {
    sha256 = "sha256",
    sha512 = "sha512"
}
//# sourceMappingURL=types.d.ts.map