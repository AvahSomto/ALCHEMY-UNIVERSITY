export const version = "basex/5.7.0";
