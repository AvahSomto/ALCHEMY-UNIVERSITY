import WebSocket from "ws";

export { WebSocket }
