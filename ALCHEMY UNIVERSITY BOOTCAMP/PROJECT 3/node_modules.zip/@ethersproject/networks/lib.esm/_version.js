export const version = "networks/5.7.1";
//# sourceMappingURL=_version.js.map