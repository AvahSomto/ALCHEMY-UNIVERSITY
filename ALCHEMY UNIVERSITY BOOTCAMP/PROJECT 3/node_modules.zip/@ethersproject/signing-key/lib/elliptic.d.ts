import _ec from "elliptic";
import EC = _ec.ec;
export { EC };
//# sourceMappingURL=elliptic.d.ts.map