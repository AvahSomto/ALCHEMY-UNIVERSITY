export const version = "abstract-signer/5.7.0";
