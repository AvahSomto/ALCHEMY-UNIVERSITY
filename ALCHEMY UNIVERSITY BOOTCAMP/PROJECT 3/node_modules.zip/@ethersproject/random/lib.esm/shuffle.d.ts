export declare function shuffled(array: Array<any>): Array<any>;
//# sourceMappingURL=shuffle.d.ts.map