export declare function randomBytes(length: number): Uint8Array;
//# sourceMappingURL=random.d.ts.map