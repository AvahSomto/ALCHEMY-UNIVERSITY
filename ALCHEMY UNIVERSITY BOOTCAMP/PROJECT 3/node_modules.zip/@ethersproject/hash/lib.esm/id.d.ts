export declare function id(text: string): string;
//# sourceMappingURL=id.d.ts.map