export const version = "abi/5.7.0";
//# sourceMappingURL=_version.js.map