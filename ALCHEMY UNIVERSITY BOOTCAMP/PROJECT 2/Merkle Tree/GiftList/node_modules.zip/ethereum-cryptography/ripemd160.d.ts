export declare const ripemd160: (msg: Uint8Array) => Uint8Array;
