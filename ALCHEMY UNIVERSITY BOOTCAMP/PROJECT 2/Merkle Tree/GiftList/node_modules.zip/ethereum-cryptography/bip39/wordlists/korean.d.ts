export { wordlist } from "@scure/bip39/wordlists/korean";
