"use strict";
throw new Error("This package has no entry-point. Please consult the README.md to learn how to use it.");
