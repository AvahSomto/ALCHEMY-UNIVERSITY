export declare const sha256: (msg: Uint8Array) => Uint8Array;
