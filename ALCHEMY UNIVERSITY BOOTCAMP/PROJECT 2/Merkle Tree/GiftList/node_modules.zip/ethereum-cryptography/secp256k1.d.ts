export { getPublicKey, sign, signSync, verify, recoverPublicKey, getSharedSecret, utils, CURVE, Point, Signature, schnorr } from "@noble/secp256k1";
